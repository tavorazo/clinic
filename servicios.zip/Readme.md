this project is a beta version of a clinic system 
